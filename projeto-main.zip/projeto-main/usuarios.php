<?php
    $gen = $_SESSION['generos'];
    $num = count($gen);
    echo "<b style='font-size: 127px;'>".$num."</b>";
?>